export interface UserData {
  email: string
  password: string
  name?: string
  age?: string
  skinType?: string
  dateOfBirth?: Date
  allergies?: string
  previousDiseases?: string
}

let isAuthenticated = false
let currentUser: UserData | null = null

export function login(email: string, password: string): Promise<void> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (email && password) {
        isAuthenticated = true
        resolve()
      } else {
        reject(new Error("Invalid credentials"))
      }
    }, 1000)
  })
}

export function signup(userData: UserData): Promise<void> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (userData.email && userData.password) {
        isAuthenticated = true
        currentUser = userData
        resolve()
      } else {
        reject(new Error("Invalid input"))
      }
    }, 1000)
  })
}

export function logout(): void {
  isAuthenticated = false
  currentUser = null
}

export function checkAuth(): Promise<boolean> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(isAuthenticated)
    }, 1000)
  })
}

export function getCurrentUser(): Promise<UserData | null> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(currentUser)
    }, 1000)
  })
}

