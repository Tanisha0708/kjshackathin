import type { UserData } from "./auth"

interface Location {
  lat: number
  lng: number
}

interface Dermatologist {
  id: string
  name: string
  specialization: string
  phone: string
  clinic: string
  location: Location
  distance: string
}

export function getUserProfile(): Promise<UserData> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        email: "user@example.com",
        name: "John Doe",
        age: "30",
        skinType: "combination",
        dateOfBirth: new Date("1993-05-15"),
        allergies: "None",
        previousDiseases: "Mild eczema",
        password: "",
      })
    }, 1000)
  })
}

export function getNearbyDermatologists(): Promise<Dermatologist[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: "1",
          name: "Dr. R. Sharma",
          specialization: "General Dermatology",
          phone: "123-456-7890",
          clinic: "123 Main St, City",
          location: { lat: 40.7128, lng: -74.006 },
          distance: "0.5 miles",
        },
        {
          id: "2",
          name: "Dr. Jane Smith",
          specialization: "Pediatric Dermatology",
          phone: "098-765-4321",
          clinic: "456 Elm St, City",
          location: { lat: 40.7148, lng: -74.0068 },
          distance: "0.8 miles",
        },
      ])
    }, 1000)
  })
}

