import { useState } from "react"
import { login, signup, type UserData } from "../utils/auth"
import { Calendar } from "@/components/ui/calendar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AuthModalProps {
  onLogin: () => void
  onClose: () => void
}

export default function AuthModal({ onLogin, onClose }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(true)
  const [userData, setUserData] = useState<UserData>({
    email: "",
    password: "",
    name: "",
    age: "",
    skinType: "",
    dateOfBirth: new Date(),
    allergies: "",
    previousDiseases: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      if (isLogin) {
        await login(userData.email, userData.password)
      } else {
        await signup(userData)
      }
      onLogin()
    } catch (error) {
      console.error("Authentication error:", error)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-8 rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <h2 className="text-2xl font-bold mb-4">{isLogin ? "Log In" : "Sign Up"}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="block mb-2 font-medium">
              Email
            </label>
            <Input
              type="email"
              id="email"
              value={userData.email}
              onChange={(e) => setUserData({ ...userData, email: e.target.value })}
              required
            />
          </div>
          <div>
            <label htmlFor="password" className="block mb-2 font-medium">
              Password
            </label>
            <Input
              type="password"
              id="password"
              value={userData.password}
              onChange={(e) => setUserData({ ...userData, password: e.target.value })}
              required
            />
          </div>

          {!isLogin && (
            <>
              <div>
                <label htmlFor="name" className="block mb-2 font-medium">
                  Full Name
                </label>
                <Input
                  type="text"
                  id="name"
                  value={userData.name}
                  onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <label htmlFor="age" className="block mb-2 font-medium">
                  Age
                </label>
                <Input
                  type="number"
                  id="age"
                  value={userData.age}
                  onChange={(e) => setUserData({ ...userData, age: e.target.value })}
                  required
                />
              </div>
              <div>
                <label htmlFor="skinType" className="block mb-2 font-medium">
                  Skin Type
                </label>
                <Select
                  value={userData.skinType}
                  onValueChange={(value) => setUserData({ ...userData, skinType: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select skin type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="dry">Dry</SelectItem>
                    <SelectItem value="oily">Oily</SelectItem>
                    <SelectItem value="combination">Combination</SelectItem>
                    <SelectItem value="sensitive">Sensitive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block mb-2 font-medium">Date of Birth</label>
                <Calendar
                  mode="single"
                  selected={userData.dateOfBirth}
                  onSelect={(date) => date && setUserData({ ...userData, dateOfBirth: date })}
                  className="rounded-md border"
                />
              </div>
              <div>
                <label htmlFor="allergies" className="block mb-2 font-medium">
                  Allergies
                </label>
                <Input
                  type="text"
                  id="allergies"
                  value={userData.allergies}
                  onChange={(e) => setUserData({ ...userData, allergies: e.target.value })}
                  placeholder="List any allergies"
                />
              </div>
              <div>
                <label htmlFor="previousDiseases" className="block mb-2 font-medium">
                  Previous Diseases
                </label>
                <Input
                  type="text"
                  id="previousDiseases"
                  value={userData.previousDiseases}
                  onChange={(e) => setUserData({ ...userData, previousDiseases: e.target.value })}
                  placeholder="List any previous skin conditions"
                />
              </div>
            </>
          )}

          <Button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded shadow-lg transform transition hover:scale-105"
          >
            {isLogin ? "Log In" : "Sign Up"}
          </Button>
        </form>
        <p className="mt-4 text-center">
          {isLogin ? "Don't have an account?" : "Already have an account?"}
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="ml-2 text-emerald-600 hover:text-emerald-700 underline"
          >
            {isLogin ? "Sign Up" : "Log In"}
          </button>
        </p>
        <Button onClick={onClose} className="mt-4 w-full bg-gray-200 hover:bg-gray-300 text-gray-800">
          Close
        </Button>
      </div>
    </div>
  )
}

