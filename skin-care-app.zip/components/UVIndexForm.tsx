import { useState } from "react"

interface UVIndexFormProps {
  onSubmit: (location: string) => void
}

export default function UVIndexForm({ onSubmit }: UVIndexFormProps) {
  const [location, setLocation] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(location)
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-4">
        <label htmlFor="location" className="block mb-2">
          Enter your location:
        </label>
        <input
          type="text"
          id="location"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="w-full px-3 py-2 border rounded"
          required
        />
      </div>
      <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
        Get UV Index
      </button>
    </form>
  )
}

