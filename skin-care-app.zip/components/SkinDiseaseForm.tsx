import { useState } from "react"

interface SkinDiseaseFormProps {
  onSubmit: (image: File) => void
}

export default function SkinDiseaseForm({ onSubmit }: SkinDiseaseFormProps) {
  const [image, setImage] = useState<File | null>(null)

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0])
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (image) {
      onSubmit(image)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-4">
        <label htmlFor="image" className="block mb-2">
          Upload an image of the affected skin area:
        </label>
        <input
          type="file"
          id="image"
          accept="image/*"
          onChange={handleImageChange}
          className="w-full px-3 py-2 border rounded"
          required
        />
      </div>
      <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded" disabled={!image}>
        Predict Skin Disease
      </button>
    </form>
  )
}

