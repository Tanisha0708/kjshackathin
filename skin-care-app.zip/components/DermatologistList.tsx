interface Dermatologist {
  name: string
  specialization: string
  phone: string
  clinic: string
}

interface DermatologistListProps {
  dermatologists: Dermatologist[]
}

export default function DermatologistList({ dermatologists }: DermatologistListProps) {
  return (
    <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {dermatologists.map((dermatologist, index) => (
        <li key={index} className="border p-4 rounded">
          <h3 className="text-xl font-bold">{dermatologist.name}</h3>
          <p>Specialization: {dermatologist.specialization}</p>
          <p>Phone: {dermatologist.phone}</p>
          <p>Clinic: {dermatologist.clinic}</p>
        </li>
      ))}
    </ul>
  )
}

