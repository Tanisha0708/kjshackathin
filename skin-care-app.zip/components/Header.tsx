import Link from "next/link"
import { Button } from "@/components/ui/button"

interface HeaderProps {
  isLoggedIn: boolean
  onLogout: () => void
}

export default function Header({ isLoggedIn, onLogout }: HeaderProps) {
  return (
    <header className="bg-emerald-600 text-white p-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/">
          <a className="text-2xl font-bold hover:text-emerald-100 transition-colors">SkinCare App</a>
        </Link>
        <nav>
          {isLoggedIn ? (
            <Button
              onClick={onLogout}
              className="bg-emerald-800 hover:bg-emerald-900 text-white font-bold py-2 px-6 rounded shadow-lg transform transition hover:scale-105"
            >
              Log Out
            </Button>
          ) : (
            <Link href="/">
              <Button className="bg-emerald-800 hover:bg-emerald-900 text-white font-bold py-2 px-6 rounded shadow-lg transform transition hover:scale-105">
                Log In
              </Button>
            </Link>
          )}
        </nav>
      </div>
    </header>
  )
}

