"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Header from "../components/Header"

interface Dermatologist {
  name: string
  distance: number
  address: string
}

export default function NearestDermatologist() {
  const [location, setLocation] = useState("")
  const [nearestDermatologists, setNearestDermatologists] = useState<Dermatologist[]>([])
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Simulate API call to get nearest dermatologists
    const mockDermatologists: Dermatologist[] = [
      { name: "Dr. Smith", distance: 1.2, address: "123 Main St, City" },
      { name: "Dr. Johnson", distance: 2.5, address: "456 Elm St, City" },
      { name: "Dr. Williams", distance: 3.8, address: "789 Oak St, City" },
    ]
    setNearestDermatologists(mockDermatologists)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-4">Find Nearest Dermatologist</h1>
        <form onSubmit={handleSubmit} className="mb-8">
          <div className="mb-4">
            <Label htmlFor="location">Enter your location</Label>
            <Input id="location" value={location} onChange={(e) => setLocation(e.target.value)} required />
          </div>
          <Button type="submit">Find Dermatologists</Button>
        </form>
        {nearestDermatologists.length > 0 && (
          <div>
            <h2 className="text-2xl font-semibold mb-2">Nearest Dermatologists</h2>
            <ul className="space-y-4">
              {nearestDermatologists.map((dermatologist, index) => (
                <li key={index} className="bg-card p-4 rounded-lg shadow">
                  <h3 className="text-xl font-semibold">{dermatologist.name}</h3>
                  <p>Distance: {dermatologist.distance.toFixed(1)} km</p>
                  <p>Address: {dermatologist.address}</p>
                </li>
              ))}
            </ul>
          </div>
        )}
        <Button onClick={() => router.push("/")} className="mt-4">
          Back to Home
        </Button>
      </main>
    </div>
  )
}

