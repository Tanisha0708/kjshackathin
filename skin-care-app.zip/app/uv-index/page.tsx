"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Header from "../components/Header"

export default function UVIndex() {
  const [location, setLocation] = useState("")
  const [uvData, setUvData] = useState<{ temperature: number; uvIndex: number } | null>(null)
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Simulate API call to get UV index and temperature
    setUvData({
      temperature: Math.floor(Math.random() * 30) + 10, // Random temperature between 10-40°C
      uvIndex: Math.floor(Math.random() * 11) + 1, // Random UV index between 1-11
    })
  }

  const getSkinCareRecommendation = (uvIndex: number) => {
    if (uvIndex <= 2) return "Low UV. Minimal sun protection required."
    if (uvIndex <= 5) return "Moderate UV. Wear sunscreen and protective clothing."
    if (uvIndex <= 7) return "High UV. Use strong sunscreen, wear a hat, and limit sun exposure."
    return "Very High UV. Avoid sun exposure, use maximum sun protection."
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-4">UV Index Checker</h1>
        <form onSubmit={handleSubmit} className="mb-8">
          <div className="mb-4">
            <Label htmlFor="location">Enter your location</Label>
            <Input id="location" value={location} onChange={(e) => setLocation(e.target.value)} required />
          </div>
          <Button type="submit">Check UV Index</Button>
        </form>
        {uvData && (
          <div className="bg-card p-4 rounded-lg shadow">
            <h2 className="text-2xl font-semibold mb-2">Results for {location}</h2>
            <p className="mb-2">Temperature: {uvData.temperature}°C</p>
            <p className="mb-2">UV Index: {uvData.uvIndex}</p>
            <p className="mb-4">{getSkinCareRecommendation(uvData.uvIndex)}</p>
          </div>
        )}
        <Button onClick={() => router.push("/")} className="mt-4">
          Back to Home
        </Button>
      </main>
    </div>
  )
}

