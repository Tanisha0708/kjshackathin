"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"

export default function Header() {
  const router = useRouter()

  const handleLogout = () => {
    // Implement logout logic here
    localStorage.removeItem("isLoggedIn")
    router.push("/")
  }

  return (
    <header className="bg-primary text-primary-foreground p-4">
      <nav className="flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">
          SkinCare App
        </Link>
        <Button onClick={handleLogout} variant="outline">
          Logout
        </Button>
      </nav>
    </header>
  )
}

