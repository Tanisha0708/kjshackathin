"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import Header from "../components/Header"

interface HistoryItem {
  date: string
  filename: string
  prediction: string
}

export default function Profile() {
  const [history, setHistory] = useState<HistoryItem[]>([])
  const router = useRouter()

  useEffect(() => {
    const storedHistory = JSON.parse(localStorage.getItem("skinDiseaseHistory") || "[]")
    setHistory(storedHistory)
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-4">Profile</h1>
        <h2 className="text-2xl font-semibold mb-2">Skin Disease Check History</h2>
        {history.length > 0 ? (
          <ul className="space-y-2">
            {history.map((item, index) => (
              <li key={index} className="bg-card p-4 rounded-lg shadow">
                <p>Date: {new Date(item.date).toLocaleString()}</p>
                <p>Image: {item.filename}</p>
                <p>Prediction: {item.prediction}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p>No history available.</p>
        )}
        <Button onClick={() => router.push("/")} className="mt-4">
          Back to Home
        </Button>
      </main>
    </div>
  )
}

