"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import Header from "./components/Header"
import LoginSignupModal from "./components/LoginSignupModal"

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    const loggedIn = localStorage.getItem("isLoggedIn")
    if (loggedIn) {
      setIsLoggedIn(true)
    } else {
      setShowModal(true)
    }
  }, [])

  const handleLogin = () => {
    setIsLoggedIn(true)
    setShowModal(false)
    localStorage.setItem("isLoggedIn", "true")
  }

  if (!isLoggedIn) {
    return <LoginSignupModal isOpen={showModal} onLogin={handleLogin} />
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-4xl font-bold mb-8">Welcome to SkinCare App</h1>
        <div className="grid grid-cols-2 gap-4">
          <Link href="/profile">
            <Button className="w-full h-24 text-xl">Profile</Button>
          </Link>
          <Link href="/uv-index">
            <Button className="w-full h-24 text-xl">UV Index</Button>
          </Link>
          <Link href="/skin-disease">
            <Button className="w-full h-24 text-xl">Check for Skin Disease</Button>
          </Link>
          <Link href="/nearest-dermatologist">
            <Button className="w-full h-24 text-xl">Nearest Dermatologist</Button>
          </Link>
          <Link href="/top-dermatologists">
            <Button className="w-full h-24 text-xl">Top Dermatologists</Button>
          </Link>
        </div>
      </main>
    </div>
  )
}

