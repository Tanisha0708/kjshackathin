"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import Header from "../components/Header"

interface Dermatologist {
  name: string
  specialization: string
  phoneNumber: string
  clinicLocation: string
}

const topDermatologists: Dermatologist[] = [
  {
    name: "Dr. Emily Johnson",
    specialization: "Cosmetic Dermatology",
    phoneNumber: "(555) 123-4567",
    clinicLocation: "789 Beauty Lane, Skintown, ST 12345",
  },
  {
    name: "Dr. Michael Lee",
    specialization: "Pediatric Dermatology",
    phoneNumber: "(555) 987-6543",
    clinicLocation: "456 Kidcare Ave, Youngville, YV 67890",
  },
  {
    name: "Dr. Sarah Martinez",
    specialization: "Skin Cancer Treatment",
    phoneNumber: "(555) 246-8135",
    clinicLocation: "321 Sunshine Blvd, Melanoma City, MC 13579",
  },
  {
    name: "Dr. David Thompson",
    specialization: "Acne and Rosacea",
    phoneNumber: "(555) 369-2580",
    clinicLocation: "654 Clear Skin Street, Acneville, AV 24680",
  },
]

export default function TopDermatologists() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-4">Top Dermatologists</h1>
        <ul className="space-y-4">
          {topDermatologists.map((dermatologist, index) => (
            <li key={index} className="bg-card p-4 rounded-lg shadow">
              <h2 className="text-2xl font-semibold">{dermatologist.name}</h2>
              <p>
                <strong>Specialization:</strong> {dermatologist.specialization}
              </p>
              <p>
                <strong>Phone:</strong> {dermatologist.phoneNumber}
              </p>
              <p>
                <strong>Clinic:</strong> {dermatologist.clinicLocation}
              </p>
            </li>
          ))}
        </ul>
        <Button onClick={() => router.push("/")} className="mt-4">
          Back to Home
        </Button>
      </main>
    </div>
  )
}

