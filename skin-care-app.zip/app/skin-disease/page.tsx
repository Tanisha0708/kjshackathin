"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Header from "../components/Header"

export default function SkinDiseaseCheck() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [prediction, setPrediction] = useState<string | null>(null)
  const router = useRouter()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0])
    }
  }

  const handlePredict = () => {
    if (selectedFile) {
      // Simulate prediction
      const diseases = ["Acne", "Eczema", "Psoriasis", "Rosacea", "Skin Cancer"]
      const randomPrediction = diseases[Math.floor(Math.random() * diseases.length)]
      setPrediction(randomPrediction)

      // Save to history (in a real app, this would be saved to a database)
      const history = JSON.parse(localStorage.getItem("skinDiseaseHistory") || "[]")
      history.push({
        date: new Date().toISOString(),
        filename: selectedFile.name,
        prediction: randomPrediction,
      })
      localStorage.setItem("skinDiseaseHistory", JSON.stringify(history))
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto mt-8 p-4">
        <h1 className="text-3xl font-bold mb-4">Skin Disease Check</h1>
        <div className="mb-4">
          <Input type="file" onChange={handleFileChange} accept="image/*" />
        </div>
        <Button onClick={handlePredict} disabled={!selectedFile} className="mb-4">
          Predict
        </Button>
        {prediction && (
          <div className="bg-card p-4 rounded-lg shadow mb-4">
            <h2 className="text-2xl font-semibold mb-2">Prediction Result</h2>
            <p>The image may show signs of: {prediction}</p>
            <p className="text-sm text-muted-foreground mt-2">
              Please consult a dermatologist for a professional diagnosis.
            </p>
          </div>
        )}
        <Button onClick={() => router.push("/")} className="mt-4">
          Back to Home
        </Button>
      </main>
    </div>
  )
}

